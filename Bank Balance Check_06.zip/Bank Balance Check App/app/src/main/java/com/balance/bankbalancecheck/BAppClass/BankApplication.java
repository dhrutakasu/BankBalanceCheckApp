package com.balance.bankbalancecheck.BAppClass;

import android.app.Application;

public class BankApplication extends Application {
}
